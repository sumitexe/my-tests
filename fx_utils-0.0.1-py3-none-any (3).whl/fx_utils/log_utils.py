""" Custom Logging Module Built on Top of Python Logging Module and LogZero"""
import os
import tempfile

from logzero import setup_default_logger, setup_logger

LOG_FILE_MAX_BYTES = 1024 * 1024
LOG_FILE_BACKUPCOUNT = 20


def get_log_filename(name):
    """ function to generate log file name """
    return os.path.join(name + '.log')


def get_log_filepath(name, log_path):
    """ generate log file path """
    return os.path.join(log_path, get_log_filename(name))


def get_logger(name, log_path=tempfile.mkdtemp()):
    """ returns a customized logger """
    return setup_logger(name=name, logfile=get_log_filepath(name, log_path), maxBytes=LOG_FILE_MAX_BYTES, backupCount=LOG_FILE_BACKUPCOUNT)


def init_default_logger(name, log_path=tempfile.mkdtemp()):
    """ update default logger """
    setup_default_logger(logfile=get_log_filepath(name, log_path), maxBytes=LOG_FILE_MAX_BYTES, backupCount=LOG_FILE_BACKUPCOUNT)
