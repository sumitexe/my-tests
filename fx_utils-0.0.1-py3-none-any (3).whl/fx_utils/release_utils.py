import os


def get_release_version():
    return os.environ.get('RELEASE_VERSION')


def get_release_environment(default='dev'):
    release_environment = os.environ.get('RELEASE_ENVIRONMENT')
    if release_environment is None:
        return default
    return release_environment


def get_service_name():
    return os.environ.get('SERVICE_NAME') or 'midas'


def get_application_type() -> str:
    """
    Returns the type of application that is currently running.

    Valid return values are:
        - 'server': current application is a flask server
        - 'job': current application is a periodic job running as kube deployment
        - 'cronjob': current application is a kube cronjob

    Default is 'server'.

    @return: currently running application's type
    """
    return os.environ.get('APPLICATION_TYPE') or 'server'


def get_deployment_environment():
    return os.environ.get('DEPLOYMENT_ENVIRONMENT')
