from twitter import OAuth, Twitter


def get_client():
    if get_client.client:
        return get_client.client

    consumer_key = "iVUIABlYhmJf5L4xArskZzY00"
    consumer_secret = "zmglMrcDTZ9296aqkyaDnOLZH48ApFRA8SE4Udt5NUmjODvdfx"
    token = "1059972621930979328-1dwcBfpjdfZ5mBRe20o4sRwevAmdLj"
    token_secret = "hefFvflBOXqPY7B8JWZdiXitc8IOl3vBYpAlSocaR13el"
    get_client.client = Twitter(
        auth=OAuth(token, token_secret, consumer_key, consumer_secret)
    )

    return get_client.client


get_client.client = None
