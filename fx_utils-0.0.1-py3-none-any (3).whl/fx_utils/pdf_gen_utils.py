import pdfkit
from jinja2 import BaseLoader, Environment


def generate_pdf_from_template(template, **kwargs):
    """
    generate_pdf_from_template generates a pdf file based on a template and a
    set of parameters.

    Parameters:
        template - a string representing an HTML template (see example below)
        kwargs - a dictionary of parameters to pass to the template renderer

    Sample template (who is a parameter):
        <p>Hello {{who}}</p>

    Usage:
        A simple use case is to store the template in s3.  You can simply download
        the template, call generate_pdf_from_template, and write the pdf back to s3.

    Library requirements:
        wkhtmltopdf - https://wkhtmltopdf.org/ - To generate the PDF, the library
        wkhtmltopdf is required.  If the library is not on our server, it will throw
        an exception.
    """
    return pdfkit.from_string(_render_template(template, kwargs))


def _render_template(template, parameters):
    """
    _render_template uses jinja2 to render the string based on the _render_template
    and 0 or more parameters

    This function is only broken out so we can perform a few simple tests on the
    rendering
    """
    return Environment(loader=BaseLoader()).from_string(template).render(parameters)
