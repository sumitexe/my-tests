import csv


def write_list_of_dicts(data, filename, fieldnames=None):
    with open(filename, 'w', newline='') as csvfile:
        keys_set = set([])
        for d in data:
            for k in d.keys():
                keys_set.add(k)
        if not fieldnames:
            fieldnames = list(keys_set)
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for d in data:
            writer.writerow(d)


def read_file_as_list_of_dicts(filename):
    ret = []
    with open(filename) as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            ret.append(row)

    return ret
