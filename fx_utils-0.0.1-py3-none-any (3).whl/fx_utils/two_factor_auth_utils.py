import datetime
import random
import secrets

import pyotp
from yubico_client import Yubico

YUBICO_CLIENT_ID = "57664"
YUBICO_CLIENT_SECRET = "3mLilqXWBZ2D3qiZG1IXnPk4z8E="


def generate_user_secret():
    return pyotp.random_base32()


def validate_user_input_code(secret, code):
    totp = pyotp.TOTP(secret)
    return totp.verify(code)


def validate_yubikey_otp(code):
    yubico_client = Yubico(YUBICO_CLIENT_ID, YUBICO_CLIENT_SECRET)
    return yubico_client.verify(code)


def get_yubikey_id_from_otp(code):
    return code[:12]


def secret_key_to_qr_code_url(secret_key, email):
    return pyotp.TOTP(secret_key).provisioning_uri(email, issuer_name="FalconX")


def generate_code(secret):
    totp = pyotp.TOTP(secret)
    return totp.at(datetime.datetime.now())


def generate_otp_using_secrets():
    otp = secrets.choice(range(1000, 999999))
    otp = '{:6d}'.format((otp)).replace(' ', '0')
    return otp


def generate_6_digit_otp():
    otp = ''
    for i in range(6):
        otp += str(random.randint(0, 9))
    return otp
