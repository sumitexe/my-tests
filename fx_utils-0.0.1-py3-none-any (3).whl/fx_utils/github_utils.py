import requests

CLIENT_ID = '7648e18b309e7176e2fb'
CLIENT_SECRET = 'fae343d6d631fac800f7d9ad378f7bfbde924376'


class Client(object):
    API_URL = 'https://api.github.com'

    def __init__(self):
        self.session = self.init_session()

    def init_session(self):
        session = requests.session()
        session.headers.update({
            'Accept': 'application/vnd.github.v3+json',
            'Accept-Encoding': 'deflate, gzip'
        })

        return session

    def request_api_endpoint(self, endpoint, params={}, timeout=10, raise_on_error=False):
        params['client_id'] = CLIENT_ID
        params['client_secret'] = CLIENT_SECRET

        api_uri = self.API_URL + endpoint
        response = self.session.get(url=api_uri,
                                    params=params,
                                    timeout=timeout)
        if not response.ok:
            status = {
                "status": {
                    "error_code": int(response.status_code),
                    "error_message": "HTTP Request ERROR (" + str(response.status_code) + ")"
                }
            }

            if raise_on_error:
                raise Exception(status)

            return status

        # parse JSON then return
        return response.json()


def is_error_response(response):
    return response['status']['error_code'] != 0


def throw_exception_on_error(response):
    if is_error_response(response):
        raise Exception(response)


def get_client():
    return Client()
