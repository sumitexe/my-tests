import logzero
from cachetools import TTLCache

# logger is used internally as a module exposing functions like info, debug, error, warning
# the implementation used is logzero - https://logzero.readthedocs.io/en/latest/
logger = logzero.logger

# local caching
local_redis_cache = TTLCache(maxsize=1024, ttl=60)
local_function_cache = TTLCache(maxsize=1024, ttl=30)
